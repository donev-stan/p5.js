function setup() {
  createCanvas(950, 950);
 
  
}

var degree = 0;

function draw() {
  
  stroke(255);
  strokeWeight(1);
  line(mouseX, mouseY, random(900), mouseY + 240);
  
}

function drawLine(x, y, l, d){
  
  
  
  
}